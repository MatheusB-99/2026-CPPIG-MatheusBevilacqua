﻿from django import forms
from django.db.models import Q
from django.forms import inlineformset_factory
from copias.models import CopiaChave
from .models import Reserva, ReservaChave


class ReservaForm(forms.ModelForm):
    class Meta:
        model = Reserva
        fields = [
            'usuario',
            'data_inicio',
            'horario_inicio',
            'data_fim',
            'horario_fim',
            'status',
        ]
        error_messages = {
            'usuario': {'required': 'O usuario da reserva e um campo obrigatorio'},
            'data_inicio': {'required': 'A data de início da reserva e um campo obrigatorio'},
            'horario_inicio': {'required': 'O horario de início da reserva e um campo obrigatorio'},
            'data_fim': {'required': 'A data de término da reserva e um campo obrigatorio'},
            'horario_fim': {'required': 'O horario de término da reserva e um campo obrigatorio'},
            'status': {'required': 'O status da reserva e um campo obrigatorio'},
        }

    def clean(self):
        cleaned_data = super().clean()
        data_inicio = cleaned_data.get('data_inicio')
        horario_inicio = cleaned_data.get('horario_inicio')
        data_fim = cleaned_data.get('data_fim')
        horario_fim = cleaned_data.get('horario_fim')

        if not data_inicio or not horario_inicio or not data_fim or not horario_fim:
            raise forms.ValidationError('Os campos de início e término da reserva são obrigatórios.')

        if data_inicio > data_fim or (data_inicio == data_fim and horario_inicio >= horario_fim):
            raise forms.ValidationError('A data e horário de término devem ser posteriores ao início.')

        return cleaned_data


class ReservaChaveForm(forms.ModelForm):
    class Meta:
        model = ReservaChave
        fields = ['copia_chave', 'data_inicio', 'horario_inicio', 'data_fim', 'horario_fim', 'status']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        available_qs = CopiaChave.objects.filter(chave__tipo='sala', status='disponivel')
        if self.instance.pk and self.instance.copia_chave_id:
            available_qs = CopiaChave.objects.filter(chave__tipo='sala').filter(
                Q(status='disponivel') | Q(pk=self.instance.copia_chave_id)
            )
        self.fields['copia_chave'].queryset = available_qs
        # Permitir deixar campos em branco para linhas vazias do formset
        self.fields['copia_chave'].required = False
        self.fields['data_inicio'].required = False
        self.fields['horario_inicio'].required = False
        self.fields['data_fim'].required = False
        self.fields['horario_fim'].required = False
        self.fields['status'].required = False

    def clean(self):
        cleaned_data = super().clean()
        copia_chave = cleaned_data.get('copia_chave')
        data_inicio = cleaned_data.get('data_inicio')
        horario_inicio = cleaned_data.get('horario_inicio')
        data_fim = cleaned_data.get('data_fim')
        horario_fim = cleaned_data.get('horario_fim')
        status = cleaned_data.get('status')

        # Se copia_chave está preenchida, todos os outros campos devem estar também
        if copia_chave:
            if not data_inicio:
                raise forms.ValidationError('Data de início é obrigatória se chave estiver selecionada.')
            if not horario_inicio:
                raise forms.ValidationError('Horário de início é obrigatório se chave estiver selecionada.')
            if not data_fim:
                raise forms.ValidationError('Data de fim é obrigatória se chave estiver selecionada.')
            if not horario_fim:
                raise forms.ValidationError('Horário de fim é obrigatório se chave estiver selecionada.')
            if not status:
                raise forms.ValidationError('Status é obrigatório se chave estiver selecionada.')

            # Validar que data_fim > data_inicio
            if data_inicio >= data_fim:
                raise forms.ValidationError('Data de fim deve ser maior que data de início.')

        return cleaned_data

    def clean_copia_chave(self):
        copia_chave = self.cleaned_data.get('copia_chave')
        if copia_chave and copia_chave.chave.tipo == 'predio':
            raise forms.ValidationError('Chave de prédio não pode ser reservada.')
        if copia_chave and self.instance.pk and self.instance.copia_chave_id == copia_chave.pk:
            return copia_chave
        if copia_chave and copia_chave.status != 'disponivel':
            raise forms.ValidationError('Cópia de chave não está disponível.')
        if copia_chave and copia_chave.em_ultima_disponivel():
            raise forms.ValidationError('Esta é a única cópia disponível desta chave; não pode ser reservada.')
        if copia_chave and copia_chave.em_uso():
            raise forms.ValidationError('Esta cópia já está associada a uma reserva ou empréstimo ativo.')
        return copia_chave


ReservaChaveFormSet = inlineformset_factory(
    Reserva,
    ReservaChave,
    form=ReservaChaveForm,
    fields=('copia_chave', 'data_inicio', 'horario_inicio', 'data_fim', 'horario_fim', 'status'),
    extra=5,
    can_delete=True
)
