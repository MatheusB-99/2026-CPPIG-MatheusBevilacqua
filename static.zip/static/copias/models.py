from django.db import models


class CopiaChave(models.Model):
	STATUS_CHOICES = [
    ('disponivel', 'Disponível'),
    ('emprestada', 'Emprestada'),
    ('inativa', 'Inativa'),
    ('manutencao', 'Manutenção'),      
    ('perdida', 'Perdida'),            
]

	chave = models.ForeignKey(
		'chaves.Chave',
		verbose_name='Chave',
		on_delete=models.CASCADE,
		related_name='copias',
		help_text='Chave de origem da copia',
	)
	status = models.CharField(
		'Status',
		max_length=15,
		choices=STATUS_CHOICES,
		help_text='Status da copia da chave',
	)
	emergencia = models.BooleanField('Emergencia', default=False, help_text='Indica se e copia de emergencia')

	class Meta:
		verbose_name = 'Copia de Chave'
		verbose_name_plural = 'Copias de Chave'
		db_table = 'copias_copiachave'

	def __str__(self):
		return f"Copia {self.id}"

	def em_ultima_disponivel(self):
		"""Retorna True se esta copia estiver com status 'disponivel' e for a ultima
		copia disponivel vinculada a `self.chave`.
		"""
		if self.status != 'disponivel':
			return False
		return not self.chave.copias.filter(status='disponivel').exclude(pk=self.pk).exists()

	def em_uso(self):
		"""Retorna True se esta copia já estiver em uma reserva ou emprestimo ativo."""
		reserva_ativa = self.reserva_chaves.filter(status__in=['reservada', 'confirmada', 'atrasada']).exists()
		emprestimo_ativo = self.emprestimo_chaves.filter(status__in=['retirada', 'atrasada']).exists()
		return reserva_ativa or emprestimo_ativo

	def bloqueada_para_uso(self):
		"""True quando a copia não pode ser escolhida para reserva/emprestimo.

		Cobre: status diferente de 'disponivel', ser a ultima disponivel, ou ja estar em uso.
		"""
		if self.status != 'disponivel':
			return True
		if self.em_ultima_disponivel():
			return True
		if self.em_uso():
			return True
		return False

# Create your models here.