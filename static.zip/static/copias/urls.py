from django.urls import path

from .views import CopiasChaveView, CopiaChaveCreateView, CopiaChaveDeleteView,  CopiaChaveUpdateView

urlpatterns = [
    path('copias/', CopiasChaveView.as_view(), name='copias_chave'),
    path('copias/nova/', CopiaChaveCreateView.as_view(), name='copia_chave_nova'),
    path('copias/<int:pk>/editar/', CopiaChaveUpdateView.as_view(), name='copia_chave_editar'),
    path('copias/<int:pk>/excluir/', CopiaChaveDeleteView.as_view(), name='copia_chave_excluir'),
]