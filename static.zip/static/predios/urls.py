from django.urls import path

from .views import PredioCreateView, PredioDeleteView, PrediosView, PredioUpdateView

urlpatterns = [
    path('predios/', PrediosView.as_view(), name='predios'),
    path('predios/novo/', PredioCreateView.as_view(), name='predio_novo'),
    path('predios/<int:pk>/editar/', PredioUpdateView.as_view(), name='predio_editar'),
    path('predios/<int:pk>/excluir/', PredioDeleteView.as_view(), name='predio_excluir'),
]