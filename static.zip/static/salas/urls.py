from django.urls import path

from .views import SalaCreateView, SalaDeleteView, SalasView, SalaUpdateView

urlpatterns = [
    path('salas/', SalasView.as_view(), name='salas'),
    path('salas/nova/', SalaCreateView.as_view(), name='sala_nova'),
    path('salas/<int:pk>/editar/', SalaUpdateView.as_view(), name='sala_editar'),
    path('salas/<int:pk>/excluir/', SalaDeleteView.as_view(), name='sala_excluir'),
]