from django.urls import path

from .views import EmprestimoCreateView, EmprestimoDevolverView, EmprestimosView, EmprestimoUpdateView


urlpatterns = [
    path('emprestimos/', EmprestimosView.as_view(), name='emprestimos'),
    path('emprestimos/novo/', EmprestimoCreateView.as_view(), name='emprestimo_novo'),
    path('emprestimos/<int:pk>/editar/', EmprestimoUpdateView.as_view(), name='emprestimo_editar'),
    path('emprestimos/<int:pk>/devolver/', EmprestimoDevolverView.as_view(), name='emprestimo_devolver'),
]