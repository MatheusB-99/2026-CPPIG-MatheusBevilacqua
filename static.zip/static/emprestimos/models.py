from django.core.exceptions import ValidationError
from django.conf import settings
from django.db import models
from django.db.models.functions import Upper


class Emprestimo(models.Model):
    class StatusEmprestimo(models.TextChoices):
        ABERTO = 'aberto', 'Aberto'
        DEVOLVIDO = 'devolvido', 'Devolvido'
        ATRASADO = 'atrasado', 'Atrasado'

    usuario = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='emprestimos')
    copias_chave = models.ManyToManyField('copias.CopiaChave', through='EmprestimoChave', related_name='emprestimos_set')
    reserva = models.OneToOneField('reservas.Reserva', on_delete=models.SET_NULL, related_name='emprestimo', null=True, blank=True)
    data_retirada = models.DateField()
    horario_retirada = models.TimeField(null=True, blank=True)
    data_prevista = models.DateField()
    horario_prevista = models.TimeField(null=True, blank=True)
    status = models.CharField(max_length=15, choices=StatusEmprestimo.choices)
    notificado_vencimento = models.BooleanField(default=False)
    notificado_atraso = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = 'Emprestimos'
        ordering = [Upper('usuario__username')]

    def clean(self):
        super().clean()
        if self.status not in {self.StatusEmprestimo.ABERTO, self.StatusEmprestimo.ATRASADO}:
            return

        for chave_rel in self.emprestimoChave_set.all():
            chave = chave_rel.copia_chave.chave
            sala = chave.sala
            if not sala or not sala.eh_exclusiva:
                continue

            conflito = Emprestimo.objects.filter(
                emprestimoChave__copia_chave__chave__sala_id=sala.id,
                status__in=[self.StatusEmprestimo.ABERTO, self.StatusEmprestimo.ATRASADO],
            )
            if self.pk:
                conflito = conflito.exclude(pk=self.pk)

            if conflito.exists():
                raise ValidationError('Sala exclusiva permite apenas um emprestimo aberto/atrasado por vez.')

    def __str__(self):
        return f"Emprestimo {self.id} - {self.get_status_display()}"


class EmprestimoChave(models.Model):
    class StatusChave(models.TextChoices):
        RETIRADA = 'retirada', 'Retirada'
        DEVOLVIDA = 'devolvida', 'Devolvida'
        ATRASADA = 'atrasada', 'Atrasada'
        PERDIDA = 'perdida', 'Perdida'

    emprestimo = models.ForeignKey(Emprestimo, on_delete=models.CASCADE, related_name='emprestimoChave_set')
    copia_chave = models.ForeignKey('copias.CopiaChave', on_delete=models.PROTECT, related_name='emprestimo_chaves')
    data_retirada = models.DateField()
    horario_retirada = models.TimeField(null=True, blank=True)
    data_prevista_devolucao = models.DateField()
    horario_prevista_devolucao = models.TimeField(null=True, blank=True)
    data_devolucao = models.DateField(null=True, blank=True)
    horario_devolucao = models.TimeField(null=True, blank=True)
    status = models.CharField(max_length=15, choices=StatusChave.choices, default=StatusChave.RETIRADA)

    class Meta:
        unique_together = ('emprestimo', 'copia_chave')
        verbose_name_plural = 'Emprestimo Chaves'

    def __str__(self):
        return f"{self.emprestimo} - {self.copia_chave}"