from django.contrib import admin

from .models import Emprestimo, EmprestimoChave


class EmprestimoChaveInline(admin.TabularInline):
	model = EmprestimoChave
	extra = 1
	fields = ('copia_chave', 'data_retirada', 'horario_retirada', 'data_prevista_devolucao', 'horario_prevista_devolucao', 'data_devolucao', 'horario_devolucao', 'status')


@admin.register(Emprestimo)
class EmprestimoAdmin(admin.ModelAdmin):
	list_display = (
		'id',
		'usuario',
		'data_retirada',
		'data_prevista',
		'status',
	)
	list_filter = ('status', 'data_retirada')
	search_fields = ('usuario__username', 'usuario__email')
	inlines = [EmprestimoChaveInline]


@admin.register(EmprestimoChave)
class EmprestimoChaveAdmin(admin.ModelAdmin):
	list_display = ('emprestimo', 'copia_chave', 'data_retirada', 'data_devolucao', 'status')
	list_filter = ('status', 'data_retirada')
	search_fields = ('emprestimo__id', 'copia_chave__id')
