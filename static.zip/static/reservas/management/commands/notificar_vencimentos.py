from django.core.management.base import BaseCommand
from django.utils import timezone
from django.conf import settings
from django.core.mail import send_mail
from datetime import datetime, timedelta

from reservas.models import Reserva
from emprestimos.models import Emprestimo


def enviar_email(usuario, assunto, mensagem):
    """Helper para enviar emails de notificação"""
    if usuario and usuario.email:
        send_mail(assunto, mensagem, settings.DEFAULT_FROM_EMAIL, [usuario.email], fail_silently=False)


def fazer_datetime_aware(dt):
    """Converte datetime para aware se necessário"""
    return dt if timezone.is_aware(dt) else timezone.make_aware(dt)


class Command(BaseCommand):
    help = 'Envia emails 10 minutos antes do vencimento e alertas de atraso'

    def processar_itens(self, queryset, tipo='reserva'):
        """Processa notificações para Reservas ou Empréstimos"""
        now = timezone.localtime()
        sent = 0

        for item in queryset:
            # Validar datas
            data_fim = getattr(item, 'data_fim', None) or getattr(item, 'data_prevista', None)
            horario_fim = getattr(item, 'horario_fim', None) or getattr(item, 'horario_prevista', None)
            
            if not data_fim or not horario_fim:
                continue

            venc = fazer_datetime_aware(datetime.combine(data_fim, horario_fim))
            aviso = venc - timedelta(minutes=10)

            # Alerta 10 minutos antes
            if aviso <= now <= venc and not item.notificado_vencimento:
                enviar_email(
                    item.usuario,
                    f'Alerta: {tipo.capitalize()} próximo do vencimento',
                    f'Seu {tipo} #{item.id} está a 10 minutos de vencer.'
                )
                item.notificado_vencimento = True
                item.save(update_fields=['notificado_vencimento'])
                sent += 1

            # Alerta de atraso
            if now > venc and item.status in ['aberta', 'ABERTO'] and not item.notificado_atraso:
                enviar_email(
                    item.usuario,
                    f'Alerta: {tipo.capitalize()} ATRASADO',
                    f'Seu {tipo} #{item.id} foi vencido! Por favor, devolva a chave imediatamente.'
                )
                item.status = 'atrasada' if tipo == 'reserva' else item.StatusEmprestimo.ATRASADO
                item.notificado_atraso = True
                item.save()
                sent += 1

        return sent

    def handle(self, *args, **options):
        sent = 0

        # Processar Reservas
        reservas = Reserva.objects.filter(status='aberta').select_related('usuario')
        sent += self.processar_itens(reservas, tipo='reserva')

        # Processar Empréstimos
        emprestimos = Emprestimo.objects.filter(status=Emprestimo.StatusEmprestimo.ABERTO).select_related('usuario')
        sent += self.processar_itens(emprestimos, tipo='empréstimo')

        self.stdout.write(self.style.SUCCESS(f'✅ Notificações enviadas: {sent}'))