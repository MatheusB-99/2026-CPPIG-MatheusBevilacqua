from django.urls import path

from .views import ReservaCreateView, ReservaCancelarView, ReservasView, ReservaUpdateView

urlpatterns = [
    path('reservas/', ReservasView.as_view(), name='reservas'),
    path('reservas/nova/', ReservaCreateView.as_view(), name='reserva_nova'),
    path('reservas/<int:pk>/editar/', ReservaUpdateView.as_view(), name='reserva_editar'),
    path('reservas/<int:pk>/cancelar/', ReservaCancelarView.as_view(), name='reserva_cancelar'),
]