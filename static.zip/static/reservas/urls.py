from django.urls import path

from .views import ReservaCreateView, ReservaCancelarView, ReservasView, ReservaUpdateView

urlpatterns = [
    path('', ReservasView.as_view(), name='reservas'),
    path('nova/', ReservaCreateView.as_view(), name='reserva_nova'),
    path('<int:pk>/editar/', ReservaUpdateView.as_view(), name='reserva_editar'),
    path('<int:pk>/cancelar/', ReservaCancelarView.as_view(), name='reserva_cancelar'),
]