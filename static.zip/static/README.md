# ChaveMaster — Visão Geral dos Módulos

Este documento resume o papel dos principais módulos do projeto e descreve o que cada arquivo relevante faz. Cole esta seção no README principal do seu repositório.

## ChaveMaster (configuração do projeto)
- `__init__.py`: marca o pacote do projeto.
- `asgi.py`: ponto de entrada ASGI (deploy assíncrono).
- `wsgi.py`: ponto de entrada WSGI (deploy tradicional).
- `settings.py`: configurações globais do Django (INSTALLED_APPS, DATABASES, TIME_ZONE, EMAIL, AUTH, STATIC, etc.).
- `urls.py`: roteamento global do projeto (inclui rotas dos apps e auth).
- `manage.py`: utilitário para executar comandos Django (migrate, runserver, commands customizados).

## App `chaves`
- `__init__.py`: marca o pacote do app.
- `apps.py`: AppConfig do app `chaves`.
- `models.py`:
	- `Chave`: modelo mestre das chaves com campos `tipo`, `sala` e `predio`.
	- `clean()`: valida integridade (ex.: chave do tipo `sala` exige `sala` e proíbe `predio`).
	- `pode_emprestar` (property): indica se a chave é emprestável (ex.: somente chaves de sala).
	- `__str__`: representação legível da chave.
- `forms.py`: formulários para criar/editar `Chave` (validações complementares).
- `views.py`:
	- `ChavesView`: listagem e busca de chaves (com `select_related` para desempenho).
	- `ChaveCreateView` / `ChaveUpdateView` / `ChaveDeleteView`: CRUD com permissões e mensagens.
- `admin.py`: registro e customizações do modelo `Chave` no admin do Django.
- `urls.py`: rotas do app `chaves`.
- `templates/`: templates HTML usados pelas views do app.
- `migrations/`: histórico de migrações do modelo `Chave`.

## App `copias`
- `__init__.py`: marca o pacote do app.
- `apps.py`: AppConfig do app `copias`.
- `models.py` (`CopiaChave`):
	- campos principais: FK para `Chave`, `status` (disponivel/emprestada/inativa/manutencao/perdida), `emergencia`.
	- helpers de domínio implementados:
		- `em_ultima_disponivel()`: True se esta cópia for a última disponível para a `Chave`.
		- `em_uso()`: True se a cópia já estiver vinculada a uma reserva ou empréstimo ativo.
		- `bloqueada_para_uso()`: agrega regras que impedem seleção (status != disponivel, última disponível, ou já em uso).
	- `__str__`: representação legível da cópia.
- `forms.py` (`CopiaChaveForm`): restringe o queryset de cópias disponíveis e trata campos opcionais em formsets.
- `views.py`:
	- `CopiasChaveView`: listagem e busca de cópias (com `select_related`/`prefetch_related`).
	- CRUD: `CopiaChaveCreateView`, `CopiaChaveUpdateView`, `CopiaChaveDeleteView` com permissões.
- `admin.py`: configurações de admin para `CopiaChave`.
- `urls.py`: rotas do app `copias`.
- `templates/`: templates para listagens e formulários de cópias.
- `migrations/`: histórico de migrações do modelo `CopiaChave`.

---
teste
