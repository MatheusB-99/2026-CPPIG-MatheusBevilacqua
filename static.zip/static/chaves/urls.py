from django.urls import path

from .views import ChaveCreateView, ChaveDeleteView, ChavesView, ChaveUpdateView

urlpatterns = [
    path('chaves/', ChavesView.as_view(), name='chaves'),
    path('chaves/nova/', ChaveCreateView.as_view(), name='chave_nova'),
    path('chaves/<int:pk>/editar/', ChaveUpdateView.as_view(), name='chave_editar'),
    path('chaves/<int:pk>/excluir/', ChaveDeleteView.as_view(), name='chave_excluir'),
]