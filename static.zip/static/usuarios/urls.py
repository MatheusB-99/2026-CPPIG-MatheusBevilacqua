from django.urls import path

from .views import UsuarioCreateView, UsuarioDeleteView, UsuarioListView, UsuarioUpdateView


urlpatterns = [
    path('usuarios/', UsuarioListView.as_view(), name='usuarios'),
    path('usuarios/novo/', UsuarioCreateView.as_view(), name='usuario_novo'),
    path('usuarios/<int:pk>/editar/', UsuarioUpdateView.as_view(), name='usuario_editar'),
    path('usuarios/<int:pk>/excluir/', UsuarioDeleteView.as_view(), name='usuario_excluir'),
]