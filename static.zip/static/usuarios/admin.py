from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DefaultUserAdmin
from django.contrib.auth.models import User

from .models import UsuarioPerfil


class UsuarioPerfilInline(admin.StackedInline):
	model = UsuarioPerfil
	can_delete = False
	verbose_name_plural = 'Perfil'


class UserAdmin(DefaultUserAdmin):
	inlines = (UsuarioPerfilInline,)


admin.site.unregister(User)
admin.site.register(User, UserAdmin)
